$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+992701+'&oi='+2170+'&ot=1&&url='+window.location, function(json){})    

});